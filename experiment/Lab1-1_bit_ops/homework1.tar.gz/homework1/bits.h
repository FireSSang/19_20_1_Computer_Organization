
int isAsciiDigit(int);
int test_isAsciiDigit(int);
int anyEvenBit();
int test_anyEvenBit();
int copyLSB(int);
int test_copyLSB(int);
int leastBitPos(int);
int test_leastBitPos(int);
int divpwr2(int, int);
int test_divpwr2(int, int);
int bitCount(int);
int test_bitCount(int);
